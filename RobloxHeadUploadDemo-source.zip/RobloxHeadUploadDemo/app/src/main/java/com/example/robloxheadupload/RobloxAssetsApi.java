package com.example.robloxheadupload;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class RobloxAssetsApi {
    private static final String CREATE_URL = "https://apis.roblox.com/assets/v1/assets";
    private RobloxAssetsApi() {}

    public static final class UploadResult {
        public final String message;
        UploadResult(String message) { this.message = message; }
    }

    public static UploadResult uploadModel(byte[] glb, String apiKey, String userId, String displayName) throws Exception {
        String boundary = "----RBXHeadUpload" + System.currentTimeMillis();
        HttpURLConnection c = (HttpURLConnection) new URL(CREATE_URL).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(20000);
        c.setReadTimeout(45000);
        c.setDoOutput(true);
        c.setRequestProperty("x-api-key", apiKey);
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        c.setRequestProperty("Accept", "application/json");

        String requestJson = "{" +
                "\"assetType\":\"Model\"," +
                "\"displayName\":\"" + jsonEscape(displayName) + "\"," +
                "\"description\":\"Uploaded from Android OBJ→GLB demo\"," +
                "\"creationContext\":{\"creator\":{\"userId\":\"" + jsonEscape(userId) + "\"}}" +
                "}";

        try (OutputStream out = c.getOutputStream()) {
            writeTextPart(out, boundary, "request", requestJson, "application/json");
            writeFilePart(out, boundary, "fileContent", "head.glb", "model/gltf-binary", glb);
            out.write(("--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
        }

        int code = c.getResponseCode();
        String body = readResponse(c, code);
        if (code < 200 || code >= 300) {
            return new UploadResult("Falha no upload (HTTP " + code + "):\n" + body);
        }

        String opPath = extract(body, "\\\"path\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"");
        if (opPath == null || !opPath.startsWith("operations/")) {
            return new UploadResult("Upload aceito pela Roblox. Resposta:\n" + body +
                    "\n\nObservação: isso cria um Model asset, não uma Cabeça do Marketplace.");
        }

        for (int i = 0; i < 12; i++) {
            Thread.sleep(1500);
            String poll = getOperation(opPath, apiKey);
            if (poll.contains("\"done\":true") || poll.contains("\"done\": true")) {
                String assetId = extract(poll, "\\\"assetId\\\"\\s*:\\s*\\\"?([0-9]+)\\\"?");
                if (assetId != null) {
                    return new UploadResult("Modelo enviado com sucesso. Asset ID: " + assetId +
                            "\n\nO arquivo está na Roblox como Model. Para virar uma Cabeça de avatar do Marketplace, ainda é necessário passar pelo Avatar Setup/validação no Roblox Studio.");
                }
                return new UploadResult("Upload concluído. Resposta da Roblox:\n" + poll +
                        "\n\nAinda não é uma Cabeça do Marketplace; é um Model asset.");
            }
        }

        return new UploadResult("Upload iniciado. Operação: " + opPath +
                "\nA Roblox ainda estava processando quando o app parou de consultar. O upload é de Model, não publicação direta de Cabeça.");
    }

    private static String getOperation(String path, String key) throws Exception {
        URL url = new URL("https://apis.roblox.com/assets/v1/" + path);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestProperty("x-api-key", key);
        int code = c.getResponseCode();
        return readResponse(c, code);
    }

    private static void writeTextPart(OutputStream out, String boundary, String name, String value, String contentType) throws Exception {
        out.write(("--" + boundary + "\r\n").getBytes(StandardCharsets.UTF_8));
        out.write(("Content-Disposition: form-data; name=\"" + name + "\"\r\n").getBytes(StandardCharsets.UTF_8));
        out.write(("Content-Type: " + contentType + "\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        out.write(value.getBytes(StandardCharsets.UTF_8));
        out.write("\r\n".getBytes(StandardCharsets.UTF_8));
    }

    private static void writeFilePart(OutputStream out, String boundary, String name, String filename, String contentType, byte[] bytes) throws Exception {
        out.write(("--" + boundary + "\r\n").getBytes(StandardCharsets.UTF_8));
        out.write(("Content-Disposition: form-data; name=\"" + name + "\"; filename=\"" + filename + "\"\r\n").getBytes(StandardCharsets.UTF_8));
        out.write(("Content-Type: " + contentType + "\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        out.write(bytes);
        out.write("\r\n".getBytes(StandardCharsets.UTF_8));
    }

    private static String readResponse(HttpURLConnection c, int code) throws Exception {
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        if (in == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line).append('\n');
        return sb.toString().trim();
    }

    private static String extract(String text, String regex) {
        Matcher m = Pattern.compile(regex).matcher(text);
        return m.find() ? m.group(1) : null;
    }

    private static String jsonEscape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
    }
}
