package com.example.robloxheadupload;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public final class ObjToGlb {
    private ObjToGlb() {}

    public static byte[] convert(String obj) throws Exception {
        List<float[]> vertices = new ArrayList<>();
        List<Integer> indices = new ArrayList<>();

        String[] lines = obj.replace("\r", "").split("\n");
        for (String raw : lines) {
            String line = raw.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;

            if (line.startsWith("v ")) {
                String[] p = line.substring(2).trim().split("\\s+");
                if (p.length < 3) continue;
                vertices.add(new float[]{Float.parseFloat(p[0]), Float.parseFloat(p[1]), Float.parseFloat(p[2])});
            } else if (line.startsWith("f ")) {
                String[] refs = line.substring(2).trim().split("\\s+");
                if (refs.length < 3) continue;
                int[] face = new int[refs.length];
                for (int i = 0; i < refs.length; i++) {
                    String token = refs[i];
                    int slash = token.indexOf('/');
                    String vi = slash >= 0 ? token.substring(0, slash) : token;
                    int idx = Integer.parseInt(vi);
                    if (idx < 0) idx = vertices.size() + idx;
                    else idx = idx - 1;
                    if (idx < 0 || idx >= vertices.size()) {
                        throw new IllegalArgumentException("OBJ contém índice de vértice inválido.");
                    }
                    face[i] = idx;
                }
                for (int i = 1; i < face.length - 1; i++) {
                    indices.add(face[0]);
                    indices.add(face[i]);
                    indices.add(face[i + 1]);
                }
            }
        }

        if (vertices.size() < 3 || indices.size() < 3) {
            throw new IllegalArgumentException("OBJ sem geometria suficiente (v/f).");
        }

        float minX = Float.POSITIVE_INFINITY, minY = Float.POSITIVE_INFINITY, minZ = Float.POSITIVE_INFINITY;
        float maxX = Float.NEGATIVE_INFINITY, maxY = Float.NEGATIVE_INFINITY, maxZ = Float.NEGATIVE_INFINITY;
        for (float[] v : vertices) {
            minX = Math.min(minX, v[0]); minY = Math.min(minY, v[1]); minZ = Math.min(minZ, v[2]);
            maxX = Math.max(maxX, v[0]); maxY = Math.max(maxY, v[1]); maxZ = Math.max(maxZ, v[2]);
        }

        int posBytes = vertices.size() * 3 * 4;
        boolean use32 = vertices.size() > 65535;
        int indexStride = use32 ? 4 : 2;
        int idxBytes = indices.size() * indexStride;
        int posPadded = align4(posBytes);
        int idxPadded = align4(idxBytes);
        int binLength = posPadded + idxPadded;

        ByteBuffer bin = ByteBuffer.allocate(binLength).order(ByteOrder.LITTLE_ENDIAN);
        for (float[] v : vertices) {
            bin.putFloat(v[0]); bin.putFloat(v[1]); bin.putFloat(v[2]);
        }
        while (bin.position() < posPadded) bin.put((byte)0);
        for (int idx : indices) {
            if (use32) bin.putInt(idx);
            else bin.putShort((short)(idx & 0xffff));
        }
        while (bin.position() < binLength) bin.put((byte)0);

        int componentType = use32 ? 5125 : 5123;
        String json = "{" +
                "\"asset\":{\"version\":\"2.0\",\"generator\":\"RobloxHeadUploadDemo\"}," +
                "\"scene\":0," +
                "\"scenes\":[{\"nodes\":[0]}]," +
                "\"nodes\":[{\"mesh\":0}]," +
                "\"meshes\":[{\"primitives\":[{\"attributes\":{\"POSITION\":0},\"indices\":1,\"mode\":4}]}]," +
                "\"buffers\":[{\"byteLength\":" + binLength + "}]," +
                "\"bufferViews\":[" +
                    "{\"buffer\":0,\"byteOffset\":0,\"byteLength\":" + posBytes + ",\"target\":34962}," +
                    "{\"buffer\":0,\"byteOffset\":" + posPadded + ",\"byteLength\":" + idxBytes + ",\"target\":34963}" +
                "]," +
                "\"accessors\":[" +
                    "{\"bufferView\":0,\"byteOffset\":0,\"componentType\":5126,\"count\":" + vertices.size() + ",\"type\":\"VEC3\",\"min\":[" + f(minX) + "," + f(minY) + "," + f(minZ) + "],\"max\":[" + f(maxX) + "," + f(maxY) + "," + f(maxZ) + "]}," +
                    "{\"bufferView\":1,\"byteOffset\":0,\"componentType\":" + componentType + ",\"count\":" + indices.size() + ",\"type\":\"SCALAR\"}" +
                "]" +
                "}";

        byte[] jsonBytes = json.getBytes(StandardCharsets.UTF_8);
        int jsonPadded = align4(jsonBytes.length);
        int totalLength = 12 + 8 + jsonPadded + 8 + binLength;
        ByteBuffer glb = ByteBuffer.allocate(totalLength).order(ByteOrder.LITTLE_ENDIAN);

        glb.putInt(0x46546C67); // glTF
        glb.putInt(2);
        glb.putInt(totalLength);

        glb.putInt(jsonPadded);
        glb.putInt(0x4E4F534A); // JSON
        glb.put(jsonBytes);
        while (glb.position() < 12 + 8 + jsonPadded) glb.put((byte)0x20);

        glb.putInt(binLength);
        glb.putInt(0x004E4942); // BIN\0
        glb.put(bin.array());

        return glb.array();
    }

    private static int align4(int n) { return (n + 3) & ~3; }
    private static String f(float x) {
        if (!Float.isFinite(x)) return "0";
        String s = Float.toString(x);
        return s.equals("-0.0") ? "0" : s;
    }
}
