package com.example.robloxheadupload;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int PICK_OBJ = 1001;
    private Uri selectedUri;
    private TextView fileLabel;
    private TextView status;
    private EditText apiKey;
    private EditText userId;
    private EditText assetName;
    private Button uploadButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int pad = dp(18);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Roblox Head Upload Demo");
        title.setTextSize(24f);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Escolha um OBJ. O app converte para GLB e envia como Model usando a Open Cloud. A Roblox não oferece endpoint público para transformar esse upload diretamente em Cabeça do Marketplace; essa etapa ainda exige Avatar Setup/Studio.");
        info.setTextSize(15f);
        info.setPadding(0, dp(10), 0, dp(16));
        root.addView(info);

        assetName = field("Nome do asset (ex.: Minha Cabeça)", false);
        root.addView(assetName);

        userId = field("Seu User ID da Roblox", false);
        userId.setInputType(InputType.TYPE_CLASS_NUMBER);
        root.addView(userId);

        apiKey = field("Open Cloud API key (não é salva)", true);
        root.addView(apiKey);

        Button pick = new Button(this);
        pick.setText("Escolher arquivo .OBJ");
        pick.setOnClickListener(v -> pickObj());
        root.addView(pick);

        fileLabel = new TextView(this);
        fileLabel.setText("Nenhum OBJ selecionado");
        fileLabel.setPadding(0, dp(8), 0, dp(8));
        root.addView(fileLabel);

        uploadButton = new Button(this);
        uploadButton.setText("Converter OBJ → GLB e enviar");
        uploadButton.setEnabled(false);
        uploadButton.setOnClickListener(v -> upload());
        root.addView(uploadButton);

        status = new TextView(this);
        status.setText("Status: aguardando arquivo.");
        status.setTextIsSelectable(true);
        status.setPadding(0, dp(14), 0, dp(24));
        root.addView(status);

        TextView warning = new TextView(this);
        warning.setText("Importante: não use seu cookie .ROBLOSECURITY. Este protótipo usa somente a Open Cloud API key oficial. Se você transformar o app em um serviço para outras pessoas, use OAuth 2.0 em vez de pedir a API key delas.");
        warning.setTextSize(13f);
        root.addView(warning);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }

    private EditText field(String hint, boolean password) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setPadding(0, dp(7), 0, dp(7));
        if (password) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        }
        return e;
    }

    private void pickObj() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, PICK_OBJ);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_OBJ && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedUri = data.getData();
            String name = FileNameUtil.getDisplayName(this, selectedUri);
            if (name == null) name = selectedUri.toString();
            fileLabel.setText(name);
            boolean obj = name.toLowerCase().endsWith(".obj");
            uploadButton.setEnabled(obj);
            status.setText(obj ? "Status: OBJ pronto para converter." : "Status: selecione um arquivo com extensão .obj");
        }
    }

    private void upload() {
        final String key = apiKey.getText().toString().trim();
        final String uid = userId.getText().toString().trim();
        final String name = assetName.getText().toString().trim();

        if (selectedUri == null) {
            status.setText("Status: escolha um OBJ.");
            return;
        }
        if (key.isEmpty() || uid.isEmpty() || name.isEmpty()) {
            status.setText("Status: preencha nome, User ID e API key.");
            return;
        }

        uploadButton.setEnabled(false);
        status.setText("Status: lendo OBJ e convertendo para GLB...");

        new Thread(() -> {
            try {
                byte[] objBytes;
                try (InputStream in = getContentResolver().openInputStream(selectedUri)) {
                    if (in == null) throw new IllegalStateException("Não foi possível abrir o arquivo.");
                    objBytes = readAll(in, 20 * 1024 * 1024);
                }

                byte[] glb = ObjToGlb.convert(new String(objBytes, StandardCharsets.UTF_8));
                runOnUiThread(() -> status.setText("Status: GLB criado (" + glb.length + " bytes). Enviando para Roblox..."));

                RobloxAssetsApi.UploadResult result = RobloxAssetsApi.uploadModel(glb, key, uid, name);
                String message = result.message;
                runOnUiThread(() -> status.setText(message));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Erro: " + e.getMessage()));
            } finally {
                runOnUiThread(() -> uploadButton.setEnabled(selectedUri != null));
            }
        }).start();
    }

    private static byte[] readAll(InputStream in, int maxBytes) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int total = 0;
        int n;
        while ((n = in.read(buf)) != -1) {
            total += n;
            if (total > maxBytes) throw new IllegalArgumentException("Arquivo maior que 20 MB.");
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
