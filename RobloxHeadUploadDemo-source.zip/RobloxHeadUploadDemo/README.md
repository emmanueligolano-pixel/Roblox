# Roblox Head Upload Demo

Protótipo Android que:

1. seleciona um arquivo `.obj`;
2. converte a geometria para `.glb` localmente;
3. envia o GLB para a Roblox Open Cloud Assets API como `Model`;
4. consulta a operação e mostra o Asset ID quando disponível.

## Limitação importante

Este projeto **não publica diretamente uma Cabeça no Marketplace**. A Roblox documenta que corpos/cabeças de avatar devem passar pela configuração e validação do Roblox Studio (Avatar Setup) antes do upload/publicação como ativo de avatar. A Open Cloud Assets API aceita modelos 3D, mas isso não equivale ao fluxo de Marketplace Head.

Um `.obj` também não carrega o rig facial, cages e poses necessários para uma cabeça dinâmica. O conversor deste demo preserva apenas a geometria (`v` e `f`); UVs, materiais, texturas, normals e rig não são preservados.

## Segurança

- Nunca cole seu cookie `.ROBLOSECURITY` neste app.
- A API key é digitada em tempo de execução e não é salva pelo código.
- Para distribuir o app para outras pessoas, implemente OAuth 2.0 em vez de pedir API keys.

## Build

Abra a pasta no Android Studio, aguarde o Gradle sincronizar e use **Build > Build APK(s)**.

Requisitos declarados:
- compileSdk 35
- minSdk 26
- targetSdk 35

## Open Cloud

A API key precisa ter acesso a **Assets** com permissão de escrita para o criador correspondente ao User ID usado no app.
